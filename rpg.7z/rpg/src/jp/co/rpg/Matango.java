package jp.co.rpg;

public class Matango {

	int hp;
	int level = 10;	//初期値が１０になった
	char suffix;
	void run() {System.out.println("お化けキノコ"+this.suffix+"は逃げ出した！");}
}
