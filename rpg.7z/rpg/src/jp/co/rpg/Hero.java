package jp.co.rpg;

public class Hero {

	String name;    //属性の定義
	int hp;
	void attack() {}//操作の定義
	void run() {System.out.println(this.name+"は逃げ出した");
				 System.out.println("GAMEOVER");
				 System.out.println(this.name+"のＨＰは"+this.hp+"でした。");}

	void sit(int sec) {this.hp += sec;
						System.out.println(name+"は、"+sec+"秒座った！");
						System.out.println("hpが"+sec+"ポイント回復した！");}
	void slip() {this.hp -= 5;
				  System.out.println(this.name+"は転んだ！");
				  System.out.println(this.name+"は５のダメージ！");}
	void sleep() {this.hp=100;
					System.out.println(this.name+"は眠って回復した！");}
	//thisはこのインスタンス
	//.は『の』の意味




}
