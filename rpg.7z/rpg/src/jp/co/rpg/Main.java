package jp.co.rpg;

public class Main {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ

		//①勇者を生成  インスタンス化→『 クラス名 変数名＝new クラス名(); 』
		 Hero h = new Hero();

		//②フィールドに初期値をセット
		 h.name = "ミナト";
		 h.hp 	= 100;
		 System.out.println("勇者"+h.name+"を生み出しました");

		 //③勇者のメソッドを呼び出していく
		 h.sit(5);
		 h.run();

		 Matango m1 = new Matango();
		 m1.hp = 50;
		 m1.suffix = 'A';
		 System.out.println("お化けキノコ"+m1.suffix+"があらわれた！");

		 Matango m2 = new Matango();
		 m2.hp =49;
		 m2.suffix = 'B';
		 System.out.println("お化けキノコ"+m2.suffix+"があらわれた！");

		 m1.run()
		 ;
		 m2.run();

	}

}
